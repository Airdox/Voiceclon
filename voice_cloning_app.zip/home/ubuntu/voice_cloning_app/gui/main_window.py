import sys
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QLabel, QLineEdit, QPushButton, QTextEdit, QComboBox, QMessageBox,
    QFileDialog, QProgressBar
)
from PyQt6.QtCore import QTimer, Qt, QMimeData
from PyQt6.QtGui import QDragEnterEvent, QDropEvent

# --- Simulated Backend (Copied from previous version for context) ---
_models = {
    "InitialModel_English": {"language": "en", "path": "path/to/initial_english_model.pth"},
}

def get_available_models_from_backend():
    return list(_models.keys())

def start_training_in_backend(audio_folder_path, model_name, epochs):
    print(f"Backend: Received request to train {model_name} with data from {audio_folder_path} for {epochs} epochs.")
    new_model_key = model_name
    if new_model_key not in _models:
        _models[new_model_key] = {"language": "en", "path": f"path/to/{new_model_key}.pth"}
        print(f"Backend: Model {new_model_key} added to simulated backend.")
        return True, f"Training for {model_name} started (simulated)."
    else:
        print(f"Backend: Model {new_model_key} already exists.")
        return False, f"Model {model_name} already exists."

def synthesize_with_backend(model_name, text_to_synthesize):
    print(f"Backend: Synthesizing 	{text_to_synthesize}	 using model {model_name}.")
    if model_name not in _models:
        return False, "Model not found in backend."
    return True, f"Synthesized speech for: 	{text_to_synthesize[:20]}...	 (Simulated)"
# --- End of Simulated Backend ---

class DropLineEdit(QLineEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event: QDropEvent):
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if urls:
                # For simplicity, take the first URL if it's a local file path (folder)
                path = urls[0].toLocalFile()
                if os.path.isdir(path): # Check if it's a directory
                    self.setText(path)
                else:
                    # Handle case where it's not a directory (e.g., show error)
                    print(f"Dropped item is not a directory: {path}")
                    QMessageBox.warning(self, "Input Error", "Please drop a folder, not a file.")
            event.acceptProposedAction()
        else:
            event.ignore()

class VoiceCloningAppGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Voice Cloning Software with Drag & Drop")
        self.setGeometry(100, 100, 700, 600) # Adjusted height for progress bar
        self.current_training_model_name = None
        self.training_timer = QTimer(self)
        self.training_timer.timeout.connect(self.update_training_progress)
        self.training_progress_value = 0

        self.main_layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.main_layout.addWidget(self.tabs)

        self._init_training_tab()
        self._init_tts_tab()

        self.setLayout(self.main_layout)
        self._populate_models_combobox() 

    def _init_training_tab(self):
        self.training_tab = QWidget()
        self.tabs.addTab(self.training_tab, "Model Training")
        training_layout = QVBoxLayout()

        folder_input_layout = QHBoxLayout()
        self.training_data_label = QLabel("Voice Samples Folder (Drag & Drop or Browse):")
        folder_input_layout.addWidget(self.training_data_label)
        # Use the custom DropLineEdit here
        self.training_data_path_edit = DropLineEdit()
        self.training_data_path_edit.setPlaceholderText("Drag & Drop folder here or click Browse")
        folder_input_layout.addWidget(self.training_data_path_edit)
        self.browse_training_data_button = QPushButton("Browse")
        self.browse_training_data_button.clicked.connect(self._browse_training_folder_action)
        folder_input_layout.addWidget(self.browse_training_data_button)
        training_layout.addLayout(folder_input_layout)

        model_name_layout = QHBoxLayout()
        self.model_name_label = QLabel("New Voice Model Name:")
        model_name_layout.addWidget(self.model_name_label)
        self.model_name_edit = QLineEdit()
        self.model_name_edit.setPlaceholderText("e.g., my_voice_model")
        model_name_layout.addWidget(self.model_name_edit)
        training_layout.addLayout(model_name_layout)

        epochs_layout = QHBoxLayout()
        self.epochs_label = QLabel("Training Epochs (e.g., 100):")
        epochs_layout.addWidget(self.epochs_label)
        self.epochs_edit = QLineEdit("100")
        epochs_layout.addWidget(self.epochs_edit)
        training_layout.addLayout(epochs_layout)

        self.start_training_button = QPushButton("Start Training")
        self.start_training_button.clicked.connect(self._start_training_action)
        training_layout.addWidget(self.start_training_button)
        
        # Add QProgressBar
        self.training_progress_bar_label = QLabel("Training Progress:")
        training_layout.addWidget(self.training_progress_bar_label)
        self.training_progress_bar = QProgressBar()
        self.training_progress_bar.setRange(0, 100)
        self.training_progress_bar.setValue(0)
        training_layout.addWidget(self.training_progress_bar)

        self.training_log_display_label = QLabel("Training Log:")
        training_layout.addWidget(self.training_log_display_label)
        self.training_log_display = QTextEdit()
        self.training_log_display.setReadOnly(True)
        self.training_log_display.setFixedHeight(150)
        training_layout.addWidget(self.training_log_display)

        training_layout.addStretch(1)
        self.training_tab.setLayout(training_layout)

    def _init_tts_tab(self):
        self.tts_tab = QWidget()
        self.tabs.addTab(self.tts_tab, "Text-to-Speech")
        tts_layout = QVBoxLayout()

        model_selection_layout = QHBoxLayout()
        self.model_select_label = QLabel("Select Trained Voice Model:")
        model_selection_layout.addWidget(self.model_select_label)
        self.model_combobox = QComboBox()
        model_selection_layout.addWidget(self.model_combobox)
        self.refresh_models_button = QPushButton("Refresh List")
        self.refresh_models_button.clicked.connect(self._populate_models_combobox_action)
        model_selection_layout.addWidget(self.refresh_models_button)
        tts_layout.addLayout(model_selection_layout)

        self.text_input_label_tts = QLabel("Enter text to synthesize:")
        tts_layout.addWidget(self.text_input_label_tts)
        self.text_input_area_tts = QTextEdit()
        self.text_input_area_tts.setPlaceholderText("Type or paste your text here...")
        self.text_input_area_tts.setFixedHeight(100)
        tts_layout.addWidget(self.text_input_area_tts)

        self.synthesize_button = QPushButton("Synthesize Speech")
        self.synthesize_button.clicked.connect(self._synthesize_action)
        tts_layout.addWidget(self.synthesize_button)

        self.synthesis_output_label = QLabel("Synthesis status will appear here.")
        tts_layout.addWidget(self.synthesis_output_label)
        
        tts_layout.addStretch(1)
        self.tts_tab.setLayout(tts_layout)

    def _browse_training_folder_action(self):
        folder_path = QFileDialog.getExistingDirectory(self, "Select Voice Samples Folder")
        if folder_path:
            self.training_data_path_edit.setText(folder_path)

    def _start_training_action(self):
        audio_path = self.training_data_path_edit.text()
        model_name = self.model_name_edit.text()
        epochs_str = self.epochs_edit.text()

        if not audio_path or not model_name or not epochs_str:
            QMessageBox.warning(self, "Input Error", "Please provide audio data path, model name, and number of epochs.")
            return
        
        try:
            epochs = int(epochs_str)
            if epochs <= 0:
                raise ValueError("Epochs must be positive")
        except ValueError:
            QMessageBox.warning(self, "Input Error", "Epochs must be a positive number.")
            return

        self.training_log_display.clear()
        self.training_log_display.append(f"Attempting to start training for model: {model_name}...")
        self.current_training_model_name = model_name
        self.training_progress_bar.setValue(0)
        self.training_progress_value = 0
        
        success, message = start_training_in_backend(audio_path, model_name, epochs)
        if success:
            self.training_log_display.append(f"Backend: {message}")
            self.training_log_display.append("Simulating training progress...")
            self.training_timer.start(100) # Update progress bar more frequently
        else:
            self.training_log_display.append(f"Backend Error: {message}")
            self.training_progress_bar.setValue(0) # Reset on error

    def update_training_progress(self):
        # Simulate progress. In a real app, this would get actual progress from backend.
        self.training_progress_value += 2 # Simulate 2% progress per tick
        if self.training_progress_value >= 100:
            self.training_progress_value = 100
            self.training_timer.stop()
            self._on_training_simulation_finish()
        self.training_progress_bar.setValue(self.training_progress_value)
        self.training_log_display.append(f"Training progress: {self.training_progress_value}%")

    def _on_training_simulation_finish(self):
        self.training_progress_bar.setValue(100)
        self.training_log_display.append(f"Training for {self.current_training_model_name} finished (simulated).")
        self._populate_models_combobox() 
        self.current_training_model_name = None 

    def _populate_models_combobox_action(self):
        self._populate_models_combobox()

    def _populate_models_combobox(self):
        self.model_combobox.clear()
        models = get_available_models_from_backend()
        if not models:
            self.model_combobox.addItem("No models available")
        else:
            self.model_combobox.addItems(models)

    def _synthesize_action(self):
        selected_model = self.model_combobox.currentText()
        text_to_synthesize = self.text_input_area_tts.toPlainText().strip()

        if not selected_model or selected_model == "No models available" or not text_to_synthesize:
            QMessageBox.warning(self, "Input Error", "Please select a model and enter text.")
            return

        success, result_message = synthesize_with_backend(selected_model, text_to_synthesize)
        if success:
            self.synthesis_output_label.setText(f"Synthesis result: {result_message}")
        else:
            self.synthesis_output_label.setText(f"Synthesis Error: {result_message}")

if __name__ == '__main__':
    import os # Required for DropLineEdit path check
    app = QApplication(sys.argv)
    window = VoiceCloningAppGUI()
    window.show()
    sys.exit(app.exec())

