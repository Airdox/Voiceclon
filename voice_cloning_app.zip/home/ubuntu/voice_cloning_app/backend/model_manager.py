import os
from voice_cloning_app.config import app_config

class ModelManager:
    def __init__(self):
        self.models_dir = app_config.MODELS_DIR
        if not os.path.exists(self.models_dir):
            os.makedirs(self.models_dir)
        print(f"ModelManager initialized. Models directory: {self.models_dir}")

    def list_trained_models(self):
        """Lists available trained voice models."""
        models = []
        if not os.path.exists(self.models_dir):
            return ["No models directory found"]
        for item in os.listdir(self.models_dir):
            # Assuming models are directories named after the model, containing model files
            # Or, if models are single files, adjust accordingly (e.g., item.endswith(".pth"))
            model_path = os.path.join(self.models_dir, item)
            if os.path.isfile(model_path) and (item.endswith("_xtts_model.pth") or item.endswith("_model.pth")):
                # A more robust check would be to see if a specific model file exists inside
                # For XTTSv2, a trained model might be a directory with config.json, model.pth, vocab.json etc.
                # For simplicity, let's assume a directory per model for now.
                # Or if we save a single .pth file with metadata, that's also an option.
                # Let's assume for now that a model is represented by a .pth file for simplicity in simulation
                if item.endswith("_xtts_model.pth") or item.endswith("_model.pth"): # Simplified convention
                    models.append(item.replace("_xtts_model.pth", "").replace("_model.pth", ""))
        
        if not models:
            return ["No models trained yet"]
        return sorted(models)

    def get_model_path(self, model_name):
        """Returns the path to a specific model's primary file or directory."""
        # This needs to align with how models are saved by TrainingManager
        # Assuming a simple .pth file for now for the main model artifact
        potential_path_1 = os.path.join(self.models_dir, f"{model_name}_xtts_model.pth")
        potential_path_2 = os.path.join(self.models_dir, f"{model_name}_model.pth")
        if os.path.exists(potential_path_1):
            return potential_path_1
        if os.path.exists(potential_path_2):
            return potential_path_2
        # If models are directories:
        # model_dir_path = os.path.join(self.models_dir, model_name)
        # if os.path.isdir(model_dir_path):
        #     return model_dir_path 
        return None

    def model_exists(self, model_name):
        return self.get_model_path(model_name) is not None

# Example usage (for testing this module independently)
if __name__ == '__main__':
    manager = ModelManager()
    print("Available models:", manager.list_trained_models())
    # To test further, you'd need to simulate model creation by TrainingManager
    # For example, create a dummy file:
    # with open(os.path.join(app_config.MODELS_DIR, "test_voice_model.pth"), "w") as f:
    #     f.write("dummy model data")
    # print("Available models after dummy creation:", manager.list_trained_models())
    # print("Path for 'test_voice':", manager.get_model_path("test_voice"))

