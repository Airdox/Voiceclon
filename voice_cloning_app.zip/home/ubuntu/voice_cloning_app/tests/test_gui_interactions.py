import pytest
from PyQt6.QtWidgets import QApplication, QLineEdit
from PyQt6.QtCore import Qt, QMimeData, QUrl
from unittest.mock import patch, MagicMock

# Adjust the import path based on your project structure
# This assumes main_window.py is in voice_cloning_app.gui
from voice_cloning_app.gui.main_window import VoiceCloningAppGUI, DropLineEdit

# Fixture to create an instance of the application for testing
@pytest.fixture
def app(qtbot):
    test_app = QApplication.instance() # Check if an instance already exists
    if test_app is None:
        test_app = QApplication([])
    
    window = VoiceCloningAppGUI()
    qtbot.addWidget(window)
    window.show()
    return window

# Test basic GUI elements are present
def test_gui_initialization(app):
    assert app.windowTitle() == "Voice Cloning Software with Drag & Drop"
    assert app.tabs.count() == 2
    assert app.tabs.tabText(0) == "Model Training"
    assert app.tabs.tabText(1) == "Text-to-Speech"

# Test Training Tab elements
def test_training_tab_elements_present(app):
    training_tab = app.training_tab
    assert training_tab.findChild(QLabel, "training_data_label") is not None
    assert training_tab.findChild(DropLineEdit, "training_data_path_edit") is not None
    assert training_tab.findChild(QPushButton, "browse_training_data_button") is not None
    assert training_tab.findChild(QLabel, "model_name_label") is not None
    assert training_tab.findChild(QLineEdit, "model_name_edit") is not None
    assert training_tab.findChild(QPushButton, "start_training_button") is not None
    assert training_tab.findChild(QLabel, "training_progress_bar_label") is not None
    assert training_tab.findChild(QProgressBar, "training_progress_bar") is not None
    assert training_tab.findChild(QTextEdit, "training_log_display") is not None

# Test TTS Tab elements
def test_tts_tab_elements_present(app):
    tts_tab = app.tts_tab
    assert tts_tab.findChild(QLabel, "model_select_label") is not None
    assert tts_tab.findChild(QComboBox, "model_combobox") is not None
    assert tts_tab.findChild(QPushButton, "refresh_models_button") is not None
    assert tts_tab.findChild(QLabel, "text_input_label_tts") is not None
    assert tts_tab.findChild(QTextEdit, "text_input_area_tts") is not None
    assert tts_tab.findChild(QPushButton, "synthesize_button") is not None
    assert tts_tab.findChild(QLabel, "synthesis_output_label") is not None

# Test Browse Button Click (mock QFileDialog)
def test_browse_button_training_tab(app, qtbot):
    with patch.object(QFileDialog, "getExistingDirectory", return_value="/fake/path/to/audio") as mock_dialog:
        qtbot.mouseClick(app.browse_training_data_button, Qt.MouseButton.LeftButton)
        mock_dialog.assert_called_once()
        assert app.training_data_path_edit.text() == "/fake/path/to/audio"

# Test Drag and Drop functionality for DropLineEdit
@pytest.fixture
def drop_line_edit(qtbot):
    widget = DropLineEdit()
    qtbot.addWidget(widget)
    widget.show()
    return widget

def test_drop_line_edit_accepts_folder_drop(drop_line_edit, qtbot):
    # Simulate a drop event with a folder URL
    mime_data = QMimeData()
    # Create a QUrl for a directory. The path must exist for toLocalFile() to work as expected in some contexts,
    # but for this test, we are primarily testing if setText is called with the path.
    # We will mock os.path.isdir to control the outcome.
    test_folder_path = "/tmp/test_drop_folder" # Example path
    urls = [QUrl.fromLocalFile(test_folder_path)]
    mime_data.setUrls(urls)

    with patch("os.path.isdir", return_value=True) as mock_isdir:
        # Simulate drag enter event
        drag_enter_event = QDragEnterEvent(QPoint(0,0), Qt.DropAction.CopyAction, mime_data, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
        drop_line_edit.dragEnterEvent(drag_enter_event)
        assert drag_enter_event.isAccepted()

        # Simulate drop event
        drop_event = QDropEvent(QPoint(0,0), Qt.DropAction.CopyAction, mime_data, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
        drop_line_edit.dropEvent(drop_event)
        mock_isdir.assert_called_with(test_folder_path)
        assert drop_line_edit.text() == test_folder_path

def test_drop_line_edit_rejects_file_drop(drop_line_edit, qtbot):
    mime_data = QMimeData()
    test_file_path = "/tmp/test_drop_file.txt"
    urls = [QUrl.fromLocalFile(test_file_path)]
    mime_data.setUrls(urls)

    with (patch("os.path.isdir", return_value=False) as mock_isdir,
          patch.object(QMessageBox, "warning") as mock_warning): # Mock QMessageBox
        # Simulate drag enter event (should still accept to check mime data)
        drag_enter_event = QDragEnterEvent(QPoint(0,0), Qt.DropAction.CopyAction, mime_data, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
        drop_line_edit.dragEnterEvent(drag_enter_event)
        assert drag_enter_event.isAccepted() # Accepts to check urls

        # Simulate drop event
        drop_event = QDropEvent(QPoint(0,0), Qt.DropAction.CopyAction, mime_data, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
        drop_line_edit.dropEvent(drop_event)
        mock_isdir.assert_called_with(test_file_path)
        assert drop_line_edit.text() == "" # Text should not be set
        mock_warning.assert_called_once_with(drop_line_edit, "Input Error", "Please drop a folder, not a file.")

# Test Start Training Button Click (simulated backend)
def test_start_training_button_valid_input(app, qtbot):
    app.training_data_path_edit.setText("/fake/audio_data")
    app.model_name_edit.setText("test_model_gui")
    app.epochs_edit.setText("50")

    with patch("voice_cloning_app.gui.main_window.start_training_in_backend", return_value=(True, "Training started (simulated).")) as mock_start_training:
        qtbot.mouseClick(app.start_training_button, Qt.MouseButton.LeftButton)
        mock_start_training.assert_called_once_with("/fake/audio_data", "test_model_gui", 50)
        assert "Attempting to start training for model: test_model_gui" in app.training_log_display.toPlainText()
        assert "Backend: Training started (simulated)." in app.training_log_display.toPlainText()
        # Test progress bar simulation (this will need QTimer to be advanced by qtbot or specific waits)
        # For simplicity, we check initial state and assume QTimer works as coded in main_window
        assert app.training_progress_bar.value() == 0 # Initially 0

# Test Start Training Button Click (invalid input - e.g., missing path)
def test_start_training_button_missing_input(app, qtbot):
    app.model_name_edit.setText("test_model_gui_fail")
    app.epochs_edit.setText("50")
    # training_data_path_edit is left empty

    with patch.object(QMessageBox, "warning") as mock_warning,
         patch("voice_cloning_app.gui.main_window.start_training_in_backend") as mock_start_training: # Ensure it's not called
        qtbot.mouseClick(app.start_training_button, Qt.MouseButton.LeftButton)
        mock_warning.assert_called_once_with(app, "Input Error", "Please provide audio data path, model name, and number of epochs.")
        mock_start_training.assert_not_called()

# Test Synthesize Button Click (simulated backend)
def test_synthesize_button_valid_input(app, qtbot):
    # Ensure there is a model to select
    app.model_combobox.clear()
    app.model_combobox.addItems(["test_model_for_synth"])
    app.model_combobox.setCurrentIndex(0)
    app.text_input_area_tts.setText("Hello from pytest")

    with patch("voice_cloning_app.gui.main_window.synthesize_with_backend", return_value=(True, "Synthesis successful (simulated).")) as mock_synthesize:
        qtbot.mouseClick(app.synthesize_button, Qt.MouseButton.LeftButton)
        mock_synthesize.assert_called_once_with("test_model_for_synth", "Hello from pytest")
        assert "Synthesis result: Synthesis successful (simulated)." in app.synthesis_output_label.text()

# Test Refresh Models Button
def test_refresh_models_button(app, qtbot):
    with patch("voice_cloning_app.gui.main_window.get_available_models_from_backend", return_value=["model1", "model2_refreshed"]) as mock_get_models:
        qtbot.mouseClick(app.refresh_models_button, Qt.MouseButton.LeftButton)
        mock_get_models.assert_called_once()
        assert app.model_combobox.count() == 2
        assert app.model_combobox.itemText(1) == "model2_refreshed"

# Note: Testing QTimer-based progress updates requires more advanced qtbot usage (e.g., qtbot.waitSignal)
# or manually advancing the timer. For this example, we focus on the immediate effects of button clicks.
# Full testing of progress bar would involve checking its value at intervals or after a simulated training completion signal.

