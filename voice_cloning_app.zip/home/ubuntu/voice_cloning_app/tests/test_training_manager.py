# test_training_manager.py
import unittest
import os
import time
from unittest.mock import patch, MagicMock, mock_open

from voice_cloning_app.config import app_config
from voice_cloning_app.backend.training_manager import TrainingManager
# AudioProcessor might be instantiated by TrainingManager, so its mock might be needed
from voice_cloning_app.backend.audio_processor import AudioProcessor 

class TestTrainingManager(unittest.TestCase):

    def setUp(self):
        # Store original config values
        self.original_logs_dir = app_config.LOGS_DIR
        self.original_models_dir = app_config.MODELS_DIR
        self.original_training_datasets_dir = app_config.TRAINING_DATASETS_DIR

        # Create temporary directories for testing
        self.test_base_dir = "/tmp/test_training_manager_files"
        self.test_logs_dir = os.path.join(self.test_base_dir, "logs")
        self.test_models_dir = os.path.join(self.test_base_dir, "models")
        self.test_training_datasets_dir = os.path.join(self.test_base_dir, "training_datasets")

        app_config.LOGS_DIR = self.test_logs_dir
        app_config.MODELS_DIR = self.test_models_dir
        app_config.TRAINING_DATASETS_DIR = self.test_training_datasets_dir

        self._cleanup_dir(self.test_logs_dir)
        self._cleanup_dir(self.test_models_dir)
        self._cleanup_dir(self.test_training_datasets_dir)
        self._cleanup_dir(self.test_base_dir) # Clean base if it exists from previous failed run

        os.makedirs(self.test_logs_dir, exist_ok=True)
        os.makedirs(self.test_models_dir, exist_ok=True)
        os.makedirs(self.test_training_datasets_dir, exist_ok=True)
        
        self.manager = TrainingManager()
        self.model_name = "test_voice_model"
        self.dummy_audio_data_path = os.path.join(self.test_training_datasets_dir, "dummy_audio_input")
        os.makedirs(self.dummy_audio_data_path, exist_ok=True)
        # Create a dummy wav file for AudioProcessor to find
        with open(os.path.join(self.dummy_audio_data_path, "sample.wav"), "w") as f:
            f.write("dummy wav data")

    def _cleanup_dir(self, dir_path):
        if not os.path.exists(dir_path):
            return
        
        items = []
        try:
            items = os.listdir(dir_path) 
        except FileNotFoundError:
            return # Directory was removed concurrently

        for item_name in items:
            item_path = os.path.join(dir_path, item_name)
            if os.path.isfile(item_path):
                try:
                    os.remove(item_path)
                except FileNotFoundError:
                    pass 
            elif os.path.isdir(item_path):
                self._cleanup_dir(item_path) 

        if os.path.exists(dir_path):
            try:
                if not os.listdir(dir_path):
                    os.rmdir(dir_path)
            except FileNotFoundError:
                pass 
            except OSError:
                # print(f"Warning: Could not remove directory {dir_path} during cleanup, possibly not empty.")
                pass

    def tearDown(self):
        self._cleanup_dir(self.test_logs_dir)
        self._cleanup_dir(self.test_models_dir)
        self._cleanup_dir(self.test_training_datasets_dir)
        if os.path.exists(self.test_base_dir) and not os.listdir(self.test_base_dir):
            os.rmdir(self.test_base_dir)

        # Restore original config values
        app_config.LOGS_DIR = self.original_logs_dir
        app_config.MODELS_DIR = self.original_models_dir
        app_config.TRAINING_DATASETS_DIR = self.original_training_datasets_dir

    def test_init_creates_logs_dir_if_not_exists(self):
        # Test if logs_dir is set correctly
        self.assertEqual(self.manager.training_logs_dir, self.test_logs_dir)
        # Test if the directory was created by setUp or TrainingManager init
        self.assertTrue(os.path.exists(self.test_logs_dir))

        # Test specific creation by TrainingManager (similar to ModelManager test)
        if os.path.exists(self.test_logs_dir):
            os.rmdir(self.test_logs_dir)
        self.assertFalse(os.path.exists(self.test_logs_dir))
        # Re-initialize to trigger __init__ logic again
        with patch("voice_cloning_app.config.app_config.LOGS_DIR", self.test_logs_dir):
            manager_reinit = TrainingManager()
            self.assertTrue(os.path.exists(self.test_logs_dir), "TrainingManager should recreate logs dir")
        # Recreate for other tests
        if not os.path.exists(self.test_logs_dir):
            os.makedirs(self.test_logs_dir)

    @patch("builtins.open", new_callable=mock_open)
    @patch("time.strftime", return_value="2023-01-01 12:00:00")
    def test_log_message(self, mock_strftime, mock_file_open):
        log_message_content = "This is a test log message."
        self.manager._log_message(self.model_name, log_message_content)
        
        expected_log_path = os.path.join(self.test_logs_dir, f"{self.model_name}_training.log")
        mock_file_open.assert_called_once_with(expected_log_path, "a")
        handle = mock_file_open()
        handle.write.assert_called_once_with(f"[2023-01-01 12:00:00] {log_message_content}\n")

    @patch("voice_cloning_app.backend.audio_processor.AudioProcessor.prepare_dataset_for_coqui")
    @patch("time.sleep") # Mock time.sleep to speed up tests
    @patch("builtins.open", new_callable=mock_open) # Mock open for logging and model saving
    def test_start_fine_tuning_dataset_preparation_fails(self, mock_open_combined, mock_sleep, mock_prepare_dataset):
        mock_prepare_dataset.return_value = (False, "Dataset prep error")
        
        success, message = self.manager.start_fine_tuning(self.dummy_audio_data_path, self.model_name, epochs=1)
        
        self.assertFalse(success)
        self.assertEqual(message, "Dataset preparation failed: Dataset prep error")
        mock_prepare_dataset.assert_called_once()
        # Check if error was logged
        log_path = os.path.join(self.test_logs_dir, f"{self.model_name}_training.log")
        # mock_open_combined.assert_any_call(log_path, "a") # Ensure log was opened
        # Need to check the content of the write call to the log
        # This is tricky if open is mocked globally. Better to mock _log_message or inspect its calls.
        with patch.object(self.manager, 
                         "_log_message") as mock_log_msg_method:
            self.manager.start_fine_tuning(self.dummy_audio_data_path, self.model_name, epochs=1)
            mock_log_msg_method.assert_any_call(self.model_name, "Dataset preparation failed: Dataset prep error")

    @patch("voice_cloning_app.backend.audio_processor.AudioProcessor.prepare_dataset_for_coqui")
    @patch("time.sleep")
    @patch("os.makedirs") # Mock os.makedirs for model saving path
    @patch("builtins.open", new_callable=mock_open) # Mock open for logging and model saving
    def test_start_fine_tuning_success(self, mock_file_open_global, mock_os_makedirs, mock_sleep, mock_prepare_dataset):
        prepared_path = os.path.join(self.test_training_datasets_dir, self.model_name + "_prepared")
        mock_prepare_dataset.return_value = (True, f"Dataset prepared at {prepared_path}")
        epochs = 5

        success, message = self.manager.start_fine_tuning(self.dummy_audio_data_path, self.model_name, epochs=epochs)

        self.assertTrue(success)
        self.assertEqual(message, f"Fine-tuning successful for {self.model_name}.")
        mock_prepare_dataset.assert_called_once_with(self.dummy_audio_data_path, prepared_path)
        self.assertGreaterEqual(mock_sleep.call_count, 1 + epochs) # 1 for setup, 1 per epoch
        
        # Check if dummy model file was created
        expected_model_file = os.path.join(self.test_models_dir, f"{self.model_name}_xtts_model.pth")
        # mock_os_makedirs.assert_any_call(os.path.dirname(expected_model_file), exist_ok=True) # if model_dir is not app_config.MODELS_DIR
        mock_file_open_global.assert_any_call(expected_model_file, "w")
        # Check logging calls (simplified)
        # For more detailed log checks, mock self.manager._log_message
        log_file_path = os.path.join(self.test_logs_dir, f"{self.model_name}_training.log")
        mock_file_open_global.assert_any_call(log_file_path, "a")
        # Example: Check if final success message was logged
        # This requires inspecting calls to the mocked open for the log file.

    @patch("voice_cloning_app.backend.audio_processor.AudioProcessor.prepare_dataset_for_coqui")
    @patch("time.sleep")
    @patch("os.makedirs")
    # Removed global patch for builtins.open here, will be patched inside the method
    def test_start_fine_tuning_model_save_fails(self, mock_os_makedirs, mock_sleep, mock_prepare_dataset):
        prepared_path = os.path.join(self.test_training_datasets_dir, self.model_name + "_prepared")
        mock_prepare_dataset.return_value = (True, f"Dataset prepared at {prepared_path}")
        
        # Define the path for the model file that should fail to open
        expected_model_file_to_fail = os.path.join(self.test_models_dir, f"{self.model_name}_xtts_model.pth")

        # This list will store actual calls to our custom side_effect mock
        actual_open_calls = []

        def open_side_effect(file_path, mode, *args, **kwargs):
            actual_open_calls.append((file_path, mode))
            if file_path == expected_model_file_to_fail and mode == "w":
                raise IOError("Cannot write model")
            # For all other calls to open (e.g., log files), use a new mock_open instance
            # to simulate a real file handle for each call.
            m = mock_open()
            return m(file_path, mode, *args, **kwargs)

        with patch("builtins.open", side_effect=open_side_effect) as mock_open_custom:
            success, message = self.manager.start_fine_tuning(self.dummy_audio_data_path, self.model_name, epochs=1)
        
        self.assertFalse(success)
        self.assertEqual(message, "Error saving simulated model: Cannot write model")

        # Verify that open was called for the log file (at least once)
        log_file_path = os.path.join(self.test_logs_dir, f"{self.model_name}_training.log")
        self.assertTrue(any(call[0] == log_file_path and call[1] == "a" for call in actual_open_calls), "Log file was not opened in append mode")
        # Verify that open was called for the model file that failed
        self.assertTrue(any(call[0] == expected_model_file_to_fail and call[1] == "w" for call in actual_open_calls), "Model file was not attempted to be opened in write mode")

    def test_get_training_log_path(self):
        expected_path = os.path.join(self.test_logs_dir, f"{self.model_name}_training.log")
        self.assertEqual(self.manager.get_training_log_path(self.model_name), expected_path)

if __name__ == "__main__":
    unittest.main()

