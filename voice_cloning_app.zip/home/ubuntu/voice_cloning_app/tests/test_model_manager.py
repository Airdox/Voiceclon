# test_model_manager.py
import unittest
import os
from unittest.mock import patch, MagicMock

# Temporarily adjust path to import app_config and ModelManager
import sys
# Assuming the tests are run from the project root or PYTHONPATH is set
# For direct execution or IDEs, this might need adjustment if voice_cloning_app is not in sys.path
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from voice_cloning_app.config import app_config
from voice_cloning_app.backend.model_manager import ModelManager

class TestModelManager(unittest.TestCase):

    def setUp(self):
        # Store original app_config values to restore them later if necessary
        self.original_models_dir = app_config.MODELS_DIR
        # Create a temporary directory for testing models_dir
        self.test_models_dir = "/tmp/test_voice_cloning_models"
        app_config.MODELS_DIR = self.test_models_dir
        
        # Ensure the test directory is clean before each test
        if os.path.exists(self.test_models_dir):
            for item in os.listdir(self.test_models_dir):
                item_path = os.path.join(self.test_models_dir, item)
                if os.path.isfile(item_path):
                    os.remove(item_path)
                # elif os.path.isdir(item_path): shutil.rmtree(item_path) # If models were dirs
        else:
            os.makedirs(self.test_models_dir)
        
        self.manager = ModelManager()

    def tearDown(self):
        # Clean up the temporary directory
        if os.path.exists(self.test_models_dir):
            for item in os.listdir(self.test_models_dir):
                item_path = os.path.join(self.test_models_dir, item)
                os.remove(item_path)
            os.rmdir(self.test_models_dir)
        # Restore original app_config values
        app_config.MODELS_DIR = self.original_models_dir

    def test_init_sets_models_dir_and_creates_if_not_exists(self):
        # Test if models_dir is set correctly
        self.assertEqual(self.manager.models_dir, self.test_models_dir)
        # Test if the directory was created by setUp or ModelManager init
        self.assertTrue(os.path.exists(self.test_models_dir))

        # Test the case where ModelManager specifically creates the directory
        # This is a bit tricky because app_config also creates it.
        # We'll remove it and re-init ModelManager to see if it creates it.
        if os.path.exists(self.test_models_dir):
            os.rmdir(self.test_models_dir)
        
        self.assertFalse(os.path.exists(self.test_models_dir))
        # app_config.MODELS_DIR is still self.test_models_dir
        # The print in app_config might run again if re-imported or if its code is re-evaluated
        # For this test, we assume app_config.MODELS_DIR is set and ModelManager handles its part.
        with patch('voice_cloning_app.config.app_config.MODELS_DIR', self.test_models_dir):
            # The ModelManager's __init__ has `if not os.path.exists(self.models_dir): os.makedirs(self.models_dir)`
            # This line is actually covered by app_config.py itself during its import.
            # To truly test ModelManager's own makedirs, app_config.MODELS_DIR would have to be a path
            # that app_config *didn't* create. This is hard to set up without complex mock patching of app_config itself.
            # Given app_config ensures MODELS_DIR exists, ModelManager's check is mostly a safeguard.
            # We will focus on ModelManager's logic assuming MODELS_DIR is provided (and exists due to app_config).
            manager_reinit = ModelManager() # This will re-run its __init__
            self.assertTrue(os.path.exists(self.test_models_dir), "ModelManager should recreate dir if app_config somehow missed it")
            # Re-create for other tests if it was removed
            if not os.path.exists(self.test_models_dir):
                 os.makedirs(self.test_models_dir)

    def test_list_trained_models_empty_dir(self):
        self.assertEqual(self.manager.list_trained_models(), ["No models trained yet"])

    @patch('os.path.exists')
    def test_list_trained_models_no_models_directory(self, mock_path_exists):
        mock_path_exists.return_value = False # Simulate models_dir does not exist
        # This test assumes that self.models_dir (app_config.MODELS_DIR) itself doesn't exist.
        # The ModelManager init tries to create it. If that creation is also mocked to fail, then this path is taken.
        # However, list_trained_models also has `if not os.path.exists(self.models_dir): return ["No models directory found"]`
        self.assertEqual(self.manager.list_trained_models(), ["No models directory found"])
        mock_path_exists.assert_called_with(self.test_models_dir) # verify it checked the models_dir

    def test_list_trained_models_with_various_files(self):
        # Create dummy model files and other files
        with open(os.path.join(self.test_models_dir, "model_A_xtts_model.pth"), "w") as f: f.write("A")
        with open(os.path.join(self.test_models_dir, "model_B_model.pth"), "w") as f: f.write("B")
        with open(os.path.join(self.test_models_dir, "some_other_file.txt"), "w") as f: f.write("txt")
        with open(os.path.join(self.test_models_dir, "model_C.pth"), "w") as f: f.write("C_generic") # Not matching convention
        # os.makedirs(os.path.join(self.test_models_dir, "not_a_model_dir")) # If models were dirs

        expected_models = sorted(["model_A", "model_B"])
        self.assertEqual(self.manager.list_trained_models(), expected_models)

    def test_list_trained_models_sorting(self):
        with open(os.path.join(self.test_models_dir, "zeta_model.pth"), "w") as f: f.write("Z")
        with open(os.path.join(self.test_models_dir, "alpha_xtts_model.pth"), "w") as f: f.write("A")
        with open(os.path.join(self.test_models_dir, "beta_model.pth"), "w") as f: f.write("B")
        
        expected_models = sorted(["alpha", "beta", "zeta"])
        self.assertEqual(self.manager.list_trained_models(), expected_models)

    def test_get_model_path_exists(self):
        model_a_name = "model_A_variant"
        model_a_filename = f"{model_a_name}_xtts_model.pth"
        model_a_path = os.path.join(self.test_models_dir, model_a_filename)
        with open(model_a_path, "w") as f: f.write("A_variant")

        self.assertEqual(self.manager.get_model_path(model_a_name), model_a_path)

        model_b_name = "model_B_simple"
        model_b_filename = f"{model_b_name}_model.pth"
        model_b_path = os.path.join(self.test_models_dir, model_b_filename)
        with open(model_b_path, "w") as f: f.write("B_simple")
        self.assertEqual(self.manager.get_model_path(model_b_name), model_b_path)

    def test_get_model_path_does_not_exist(self):
        self.assertIsNone(self.manager.get_model_path("non_existent_model"))

    def test_model_exists(self):
        model_name = "existing_model"
        model_filename = f"{model_name}_model.pth"
        model_path = os.path.join(self.test_models_dir, model_filename)
        with open(model_path, "w") as f: f.write("exists")

        self.assertTrue(self.manager.model_exists(model_name))

    def test_model_does_not_exist(self):
        self.assertFalse(self.manager.model_exists("ghost_model"))

if __name__ == '__main__':
    unittest.main()

