import pytest
from voice_cloning_app.backend.model_manager import ModelManager
from voice_cloning_app.config import app_config
import os

@pytest.fixture
def model_manager(tmp_path):
    # Override the default MODELS_DIR for testing to use a temporary path
    original_models_dir = app_config.MODELS_DIR
    app_config.MODELS_DIR = str(tmp_path / "user_models")
    if not os.path.exists(app_config.MODELS_DIR):
        os.makedirs(app_config.MODELS_DIR)
    
    manager = ModelManager()
    yield manager
    
    # Restore original models_dir after test
    app_config.MODELS_DIR = original_models_dir

def test_model_manager_initialization(model_manager):
    assert model_manager.models_dir is not None
    assert os.path.exists(model_manager.models_dir)

def test_list_trained_models_empty(model_manager):
    assert model_manager.list_trained_models() == ["No models trained yet"]

def test_list_trained_models_with_dummy_model(model_manager):
    # Create a dummy model file (adjust based on how ModelManager identifies models)
    dummy_model_name = "test_voice_model.pth"
    with open(os.path.join(model_manager.models_dir, dummy_model_name), "w") as f:
        f.write("dummy model data")
    
    expected_model_name = "test_voice"
    assert expected_model_name in model_manager.list_trained_models()

def test_get_model_path_not_exists(model_manager):
    assert model_manager.get_model_path("non_existent_model") is None

def test_get_model_path_exists(model_manager):
    dummy_model_name_file = "another_test_voice_model.pth"
    dummy_model_name = "another_test_voice"
    model_file_path = os.path.join(model_manager.models_dir, dummy_model_name_file)
    with open(model_file_path, "w") as f:
        f.write("dummy model data")
    
    assert model_manager.get_model_path(dummy_model_name) == model_file_path

def test_model_exists(model_manager):
    assert not model_manager.model_exists("unheard_of_model")
    
    dummy_model_name_file = "yet_another_test_voice_model.pth"
    dummy_model_name = "yet_another_test_voice"
    model_file_path = os.path.join(model_manager.models_dir, dummy_model_name_file)
    with open(model_file_path, "w") as f:
        f.write("dummy model data")
    assert model_manager.model_exists(dummy_model_name)

# Add more tests for other backend modules (audio_processor, training_manager, inference_manager)
# These will likely require more complex mocking if they interact with Coqui TTS directly.

