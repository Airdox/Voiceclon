# test_audio_processor.py
import unittest
import os
from unittest.mock import patch, MagicMock, mock_open

from voice_cloning_app.config import app_config # Though not directly used by AudioProcessor, good for context
from voice_cloning_app.backend.audio_processor import AudioProcessor

class TestAudioProcessor(unittest.TestCase):

    def setUp(self):
        self.processor = AudioProcessor()
        # Create a temporary directory for testing audio folders
        self.test_audio_base_dir = "/tmp/test_audio_processor_files"
        if not os.path.exists(self.test_audio_base_dir):
            os.makedirs(self.test_audio_base_dir)
        
        self.mock_audio_folder = os.path.join(self.test_audio_base_dir, "mock_audio_folder")
        self.mock_dataset_output = os.path.join(self.test_audio_base_dir, "mock_dataset_output")

        # Clean up before each test
        self._cleanup_dir(self.mock_audio_folder)
        self._cleanup_dir(self.mock_dataset_output)
        os.makedirs(self.mock_audio_folder, exist_ok=True)
        os.makedirs(self.mock_dataset_output, exist_ok=True)

    def _cleanup_dir(self, dir_path):
        if os.path.exists(dir_path):
            for item in os.listdir(dir_path):
                item_path = os.path.join(dir_path, item)
                if os.path.isfile(item_path):
                    os.remove(item_path)
                elif os.path.isdir(item_path):
                    # import shutil; shutil.rmtree(item_path) # If subdirs were created
                    pass # For now, only files are created by tests
            os.rmdir(dir_path)

    def tearDown(self):
        # Clean up the base temporary directory
        self._cleanup_dir(self.mock_audio_folder)
        self._cleanup_dir(self.mock_dataset_output)
        if os.path.exists(self.test_audio_base_dir):
            if not os.listdir(self.test_audio_base_dir): # Only remove if empty
                 os.rmdir(self.test_audio_base_dir)
            else: # Or force remove if necessary, but be careful
                # import shutil; shutil.rmtree(self.test_audio_base_dir)
                pass 

    def test_init(self):
        # Test basic initialization (e.g., if it prints something or sets attributes)
        # The current __init__ only prints. We can capture stdout if needed for coverage.
        with patch("builtins.print") as mock_print:
            proc = AudioProcessor()
            mock_print.assert_called_with("AudioProcessor initialized.")

    @patch("os.path.exists")
    @patch("os.path.isdir")
    def test_validate_audio_files_folder_not_found(self, mock_isdir, mock_exists):
        mock_exists.return_value = False
        mock_isdir.return_value = False # Should not be called if exists is false
        success, message = self.processor.validate_audio_files("/non/existent/folder")
        self.assertFalse(success)
        self.assertEqual(message, "Audio folder not found or is not a directory.")
        mock_exists.assert_called_once_with("/non/existent/folder")

    @patch("os.path.exists", return_value=True)
    @patch("os.path.isdir", return_value=False)
    def test_validate_audio_files_path_is_not_directory(self, mock_isdir, mock_exists):
        success, message = self.processor.validate_audio_files("/path/to/a_file")
        self.assertFalse(success)
        self.assertEqual(message, "Audio folder not found or is not a directory.")
        mock_exists.assert_called_once_with("/path/to/a_file")
        mock_isdir.assert_called_once_with("/path/to/a_file")

    @patch("os.path.exists", return_value=True)
    @patch("os.path.isdir", return_value=True)
    @patch("os.listdir", return_value=[])
    def test_validate_audio_files_empty_folder(self, mock_listdir, mock_isdir, mock_exists):
        success, message = self.processor.validate_audio_files(self.mock_audio_folder)
        self.assertFalse(success)
        self.assertEqual(message, "No WAV files found in the specified folder.")

    @patch("os.path.exists", return_value=True)
    @patch("os.path.isdir", return_value=True)
    @patch("os.listdir", return_value=["audio1.wav", "audio2.WAV", "note.txt"])
    def test_validate_audio_files_valid_wav_files_present(self, mock_listdir, mock_isdir, mock_exists):
        success, message = self.processor.validate_audio_files(self.mock_audio_folder)
        self.assertTrue(success)
        self.assertEqual(message, "Found 2 WAV files. Validation successful (simulated).")

    @patch("os.path.exists", return_value=True)
    @patch("os.path.isdir", return_value=True)
    @patch("os.listdir", return_value=["image.jpg", "document.pdf"])
    def test_validate_audio_files_no_wav_files(self, mock_listdir, mock_isdir, mock_exists):
        success, message = self.processor.validate_audio_files(self.mock_audio_folder)
        self.assertFalse(success)
        self.assertEqual(message, "No WAV files found in the specified folder.")

    def test_prepare_dataset_for_coqui_validation_fails(self):
        with patch.object(self.processor, "validate_audio_files", return_value=(False, "Validation failed error")) as mock_validate:
            success, message = self.processor.prepare_dataset_for_coqui(self.mock_audio_folder, self.mock_dataset_output)
            self.assertFalse(success)
            self.assertEqual(message, "Validation failed error")
            mock_validate.assert_called_once_with(self.mock_audio_folder)

    @patch("os.listdir")
    @patch("os.makedirs") # Mock makedirs for the output path
    @patch("builtins.open", new_callable=mock_open)
    def test_prepare_dataset_for_coqui_success(self, mock_file_open, mock_makedirs, mock_listdir):
        # Setup mocks
        mock_listdir.return_value = ["sample1.wav", "sample2.WAV"]
        # Mock validate_audio_files to return success
        with patch.object(self.processor, "validate_audio_files", return_value=(True, "Validation OK")) as mock_validate:
            success, message = self.processor.prepare_dataset_for_coqui(self.mock_audio_folder, self.mock_dataset_output)
            
            self.assertTrue(success)
            expected_metadata_path = os.path.join(self.mock_dataset_output, "metadata.csv")
            self.assertEqual(message, f"Dataset prepared successfully at {expected_metadata_path} (simulated).")
            
            mock_validate.assert_called_once_with(self.mock_audio_folder)
            # Check if output directory was potentially created
            # If it already exists, makedirs might not be called, or called with exist_ok=True
            # The current implementation of prepare_dataset_for_coqui calls os.makedirs without exist_ok=True
            # So, if the directory exists, it would raise FileExistsError unless we mock os.path.exists for it too.
            # For simplicity, let's assume it might be called.
            # mock_makedirs.assert_called_with(self.mock_dataset_output) # This depends on whether it existed
            
            mock_file_open.assert_called_once_with(expected_metadata_path, "w")
            handle = mock_file_open()
            expected_calls = [
                unittest.mock.call(f"{os.path.join(self.mock_audio_folder, 'sample1.wav')}|default_speaker|This is a sample transcript.\n"),
                unittest.mock.call(f"{os.path.join(self.mock_audio_folder, 'sample2.WAV')}|default_speaker|This is a sample transcript.\n")
            ]
            handle.write.assert_has_calls(expected_calls, any_order=False)

    @patch("os.listdir", return_value=["sample1.wav"])
    @patch("os.makedirs")
    @patch("builtins.open", side_effect=IOError("Disk full"))
    def test_prepare_dataset_for_coqui_io_error_writing_metadata(self, mock_file_open_error, mock_makedirs, mock_listdir):
        with patch.object(self.processor, "validate_audio_files", return_value=(True, "Validation OK")):
            success, message = self.processor.prepare_dataset_for_coqui(self.mock_audio_folder, self.mock_dataset_output)
            self.assertFalse(success)
            self.assertEqual(message, "Error preparing dataset: Disk full")

if __name__ == '__main__':
    unittest.main()

