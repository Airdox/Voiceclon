# test_inference_manager.py
import unittest
import os
import time
from unittest.mock import patch, MagicMock, mock_open

from voice_cloning_app.config import app_config
from voice_cloning_app.backend.inference_manager import InferenceManager
from voice_cloning_app.backend.model_manager import ModelManager # For mocking

class TestInferenceManager(unittest.TestCase):

    def setUp(self):
        self.original_models_dir = app_config.MODELS_DIR
        self.test_base_dir = "/tmp/test_inference_manager_files"
        self.test_models_dir = os.path.join(self.test_base_dir, "models")
        self.test_synthesized_audio_dir = os.path.join(self.test_base_dir, "synthesized_audio_output")

        app_config.MODELS_DIR = self.test_models_dir

        self._cleanup_dir(self.test_models_dir)
        self._cleanup_dir(self.test_synthesized_audio_dir)
        self._cleanup_dir(self.test_base_dir)

        os.makedirs(self.test_models_dir, exist_ok=True)
        # The InferenceManager itself creates the synthesized_audio_output dir if needed

        self.model_name = "test_synth_model"
        self.manager = InferenceManager()

    def _cleanup_dir(self, dir_path):
        if not os.path.exists(dir_path):
            return
        items = []
        try:
            items = os.listdir(dir_path)
        except FileNotFoundError:
            return
        for item_name in items:
            item_path = os.path.join(dir_path, item_name)
            if os.path.isfile(item_path):
                try:
                    os.remove(item_path)
                except FileNotFoundError:
                    pass
            elif os.path.isdir(item_path):
                self._cleanup_dir(item_path)
        if os.path.exists(dir_path):
            try:
                if not os.listdir(dir_path):
                    os.rmdir(dir_path)
            except FileNotFoundError:
                pass
            except OSError:
                pass

    def tearDown(self):
        self._cleanup_dir(self.test_models_dir)
        self._cleanup_dir(self.test_synthesized_audio_dir)
        if os.path.exists(self.test_base_dir) and not os.listdir(self.test_base_dir):
             os.rmdir(self.test_base_dir)
        app_config.MODELS_DIR = self.original_models_d
    @patch("voice_cloning_app.backend.inference_manager.ModelManager") # Patch where it's used by InferenceManager
    def test_init(self, MockModelManagerInstance):
        # Test that ModelManager is instantiated when InferenceManager is created
        # The instance self.manager is created in setUp, so ModelManager was already called.
        # To test the __init__ specifically, we create a new instance here under the patch.
        manager = InferenceManager()
        MockModelManagerInstance.assert_called_once()
        self.assertEqual(manager.models_dir, self.test_models_dir)

    @patch("voice_cloning_app.backend.inference_manager.ModelManager")
    def test_synthesize_speech_model_not_found(self, MockModelManagerInstance):
        # Configure the mock instance that self.manager.model_manager will be
        mock_mm_instance = MockModelManagerInstance.return_value
        mock_mm_instance.model_exists.return_value = False

        # Re-initialize manager to use the mocked ModelManager instance from this test's scope
        current_manager = InferenceManager() 
        success, message, audio_file = current_manager.synthesize_speech("non_existent_model", "test text")
        
        self.assertFalse(success)
        # Adjusting the expected message to be more precise based on typical output
        # The actual message is: f"Model \t{model_name}\t not found. Please ensure it is trained and available."
        self.assertEqual(message, "Model \tnon_existent_model\t not found. Please ensure it is trained and available.")
        self.assertIsNone(audio_file)
        mock_mm_instance.model_exists.assert_called_once_with("non_existent_model")

    @patch("voice_cloning_app.backend.inference_manager.ModelManager") # Patch at the module level of InferenceManager
    @patch("time.sleep")
    @patch("os.makedirs") 
    @patch("builtins.open", new_callable=mock_open)
    def test_synthesize_speech_success(self, mock_file_open, mock_os_makedirs, mock_sleep, MockModelManagerInstance):
        # Configure the mock ModelManager instance
        mock_mm_instance = MockModelManagerInstance.return_value
        mock_mm_instance.model_exists.return_value = True
        dummy_model_path = os.path.join(self.test_models_dir, f"{self.model_name}_xtts_model.pth")
        mock_mm_instance.get_model_path.return_value = dummy_model_path

        text_to_synthesize = "This is a test sentence."
        output_filename = "custom_output.wav"

        # Create a new InferenceManager instance for this test to ensure it uses the patched ModelManager
        current_manager = InferenceManager()
        success, message, audio_file_path = current_manager.synthesize_speech(self.model_name, text_to_synthesize, output_filename=output_filename)

        self.assertTrue(success)
        
        current_working_dir = os.getcwd() 
        # InferenceManager creates "synthesized_audio_output" in the CWD.
        expected_output_dir_name = "synthesized_audio_output"
        expected_full_output_path = os.path.join(current_working_dir, expected_output_dir_name, output_filename)

        self.assertEqual(message, f"Speech synthesized successfully (simulated). Output saved to: {expected_full_output_path}")
        self.assertEqual(audio_file_path, expected_full_output_path)

        mock_mm_instance.model_exists.assert_called_once_with(self.model_name)
        mock_mm_instance.get_model_path.assert_called_once_with(self.model_name)
        mock_sleep.assert_called_once_with(1)
        
        # Check if os.makedirs was called for the output directory if it didn't exist.
        # We can patch os.path.exists for this specific check.
        with patch("os.path.exists", return_value=False) as mock_path_exists_for_output_dir:
            # Re-call synthesize_speech or parts of it if makedirs is conditional and we want to test that condition.
            # For now, let's assume the initial call covers the logic if the dir needs creation.
            # If the dir is created by os.makedirs(..., exist_ok=True), this is harder to assert without more context.
            # The current InferenceManager code: `if not os.path.exists(simulated_output_dir): os.makedirs(simulated_output_dir)`
            # So, if it doesn't exist, makedirs is called.
            # We can check if mock_os_makedirs was called with the correct path.
            # This requires the test to ensure the directory does not exist before the call.
            # The _cleanup_dir in setUp should handle this for the base test_synthesized_audio_dir.
            # However, InferenceManager creates it in CWD.
            # Let's ensure the CWD version is cleaned up if it exists from a previous run for this specific test.
            cwd_output_dir = os.path.join(current_working_dir, expected_output_dir_name)
            if os.path.exists(cwd_output_dir):
                self._cleanup_dir(cwd_output_dir) # Use existing cleanup
            
            # Re-instance and re-call to ensure clean state for makedirs check
            MockModelManagerInstance.reset_mock() # Reset for the new instance
            mock_mm_instance_rerun = MockModelManagerInstance.return_value
            mock_mm_instance_rerun.model_exists.return_value = True
            mock_mm_instance_rerun.get_model_path.return_value = dummy_model_path
            mock_os_makedirs.reset_mock() # Reset this mock too

            current_manager_rerun = InferenceManager()
            current_manager_rerun.synthesize_speech(self.model_name, text_to_synthesize, output_filename=output_filename)
            mock_os_makedirs.assert_called_with(cwd_output_dir)

        mock_file_open.assert_called_with(expected_full_output_path, "w") # Use assert_called_with for the last call
        handle = mock_file_open()
        handle.write.assert_called_with(f"This is simulated audio output for the text: \t{text_to_synthesize}\t using model \t{self.model_name}\t.")

    @patch("voice_cloning_app.backend.inference_manager.ModelManager")
    @patch("time.sleep")
    @patch("os.makedirs")
    @patch("builtins.open", side_effect=IOError("Cannot write audio file"))
    def test_synthesize_speech_save_fails(self, mock_open_error, mock_os_makedirs, mock_sleep, MockModelManagerInstance):
        mock_mm_instance = MockModelManagerInstance.return_value
        mock_mm_instance.model_exists.return_value = True
        dummy_model_path = os.path.join(self.test_models_dir, f"{self.model_name}_xtts_model.pth")
        mock_mm_instance.get_model_path.return_value = dummy_model_path
        text_to_synthesize = "Test text for save failure."

        current_manager = InferenceManager()
        success, message, audio_file_path = current_manager.synthesize_speech(self.model_name, text_to_synthesize)

        self.assertFalse(success)
        self.assertEqual(message, "Error saving simulated synthesized speech: Cannot write audio file")
        self.assertIsNone(audio_file_path)

    @patch("voice_cloning_app.backend.inference_manager.ModelManager")
    @patch("time.sleep")
    @patch("os.makedirs")
    @patch("builtins.open", new_callable=mock_open)
    @patch("builtins.print") 
    def test_synthesize_speech_long_text_truncation_in_log(self, mock_print, mock_file_open, mock_os_makedirs, mock_sleep, MockModelManagerInstance):
        mock_mm_instance = MockModelManagerInstance.return_value
        mock_mm_instance.model_exists.return_value = True
        dummy_model_path = os.path.join(self.test_models_dir, f"{self.model_name}_xtts_model.pth")
        mock_mm_instance.get_model_path.return_value = dummy_model_path
        
        long_text = "a" * 200
        truncated_text_log = long_text[:100] + "..."
        current_manager = InferenceManager()
        current_manager.synthesize_speech(self.model_name, long_text)
        
        mock_print.assert_any_call(f"Text: \t{truncated_text_log}")
if __name__ == "__main__":
    unittest.main()

