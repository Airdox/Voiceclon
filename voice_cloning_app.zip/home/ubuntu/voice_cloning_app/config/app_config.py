import os

# Configuration for the application

# Base directory for user-specific files (models, datasets, logs)
# In a real application, this might be platform-dependent (e.g., using appdirs library)
USER_FILES_BASE_DIR = os.path.expanduser(os.path.join("~", ".local", "share", "VoiceCloningApp"))

MODELS_DIR = os.path.join(USER_FILES_BASE_DIR, "models")
TRAINING_DATASETS_DIR = os.path.join(USER_FILES_BASE_DIR, "training_datasets")
LOGS_DIR = os.path.join(USER_FILES_BASE_DIR, "logs")

# Ensure these directories exist
if not os.path.exists(MODELS_DIR):
    os.makedirs(MODELS_DIR)
if not os.path.exists(TRAINING_DATASETS_DIR):
    os.makedirs(TRAINING_DATASETS_DIR)
if not os.path.exists(LOGS_DIR):
    os.makedirs(LOGS_DIR)

# Default Coqui TTS base model for fine-tuning (example)
# This should be configurable or detected
DEFAULT_BASE_MODEL_XTTS = "tts_models/multilingual/multi-dataset/xtts_v2"

# Training parameters defaults
DEFAULT_EPOCHS = 100 # Example, adjust based on XTTS recommendations
DEFAULT_BATCH_SIZE = 8 # Example, adjust based on XTTS and GPU memory

print(f"User models directory: {MODELS_DIR}")
print(f"User training datasets directory: {TRAINING_DATASETS_DIR}")
print(f"User logs directory: {LOGS_DIR}")

